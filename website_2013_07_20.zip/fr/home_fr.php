<!DOCTYPE html>
<html>
<link rel="stylesheet" href="css/home.css">

<style type="text/css">
<!--
.style1 {
	font-size: 36px
}
.style2 {
	font-size: 36px;
	font-style: italic;
	font-weight: bold;
}
-->
</style>
<head>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.0/jquery.min.js"></script>
<script type="text/javascript" src="js/myjs.js"></script>
<script type="text/javascript" src="js/js_home.js"></script>
</head>
	
	<br/>
    <br/>
    <br/>
  <div>
  	<div align="center" class="style1">
  	  <h2><span class="style2">Le site est actuellement en maintenance</span>
        <img src="../images/france.jpg" width="70" height="70"></h2>
  	</div>
  </div>
      
</html> 

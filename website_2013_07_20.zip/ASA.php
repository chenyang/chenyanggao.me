<!DOCTYPE html>
<html>
<link rel="stylesheet" href="css/projects_detail.css">
	

        
<!---div projects_left, show of projects--->
<div id="projects_detail">
     <section>
           	<article class="article_left">
            <div class="project_description">
            <h2>
            	ASA QLims: Tablet Prototype for Laboratory System
            </h2>
            	<img src="images/details_images/ASA_01.png" width="160" height="100" align="right" style="margin-top:10px"/>
            <p>        
            	 The prototype includes multi-platform supports, QR codes, email and web services. I established the system architecture and implemented core javascript part that associate RESTFul web service and UI..Also I provided research works for technology choosing.
            </p>
            </div>
            
            
            
            <div class="project_precision">
              <header>Overview</header>
              <p>
              <a href="http://www.advancedsolutionsaccelerator.com/">ASA</a>, which stands for Advanced Solution Accelerator, is a locally based Laboratory system provider company. Our project team's main mission is to research, advice and finally construct a prototype for 100Lims, a laboratory system built by ASA. Eventually we have decided to develop 2 version of this prototype: QLims and QRLims respectively for Android Tablet and Mobile. 
              </p>
              <p>
              Our project contains mainly 3 parts: Usability Analysis, technology research and prototype construction: QLims and QRLims. I wrote technology research and during development phase, I worte QRLims and provided core Javascript programming to connect UI and RESTFul Web services.

              </p>
              <br/>
              
              
               <header>Technology Research & Choose</header>
              <p>
				During the case study phase, I researched many mobile-related technologies such as Accelerator, PhoneGap, Jquery Mobile or pure development. Since the project will be deployed over many platforms in the future, we have chosen PhoneGap and jQuery Mobile for fast development. 
				Besides, there is no need to learn Object-C or Java and with javascript it's much easier to be understood by all team members.Finally I constructed a table of comparation between technology choosing dedicated for the project.
              </p>
              <p>
				No doubt we have hesitated on technology choosing between Pure development, Accelerator (Titanium), PhoneMobile site (Pure JQuery Mobile or related) and PhoneGap. Below is a comparison table between different combination of technologies and shows why we have chosen PhoneGap eventually.
              </p>
			   <div class="image" style="clear:both">
                      <div class="project_show_image" style="float:left">
        <a href="images/details_images/ASA_04.jpg" class="highslide" onclick="return hs.expand(this)"><img src="images/details_images/ASA_04.jpg" alt="Highslide JS" title="Click to enlarge" width="190" height="140"/></a>
                          <div>Technology Comparision Table</div>
                      </div>


                      <div class="project_show_image" style="float:left">
                             <a href="images/details_images/ASA_06.jpg" class="highslide" onclick="return hs.expand(this)"><img src="images/details_images/ASA_06.jpg" alt="Highslide JS" title="Click to enlarge" width="190" height="140"/></a>
                          <div>QLims feature</div>
                      </div>



                      <div class="project_show_image" style="clear:both">
                             <a href="images/details_images/ASA_05.jpg" class="highslide" onclick="return hs.expand(this)"><img src="images/details_images/ASA_05.jpg" alt="Highslide JS" title="Click to enlarge" width="190" height="140"/></a>
                          <div>QRLims feature</div>
                      </div>



               </div>               
					
                <header>About QLims & QRLims</header>
				<p>
				Why we call it QLims and QRLims? Q, stands for "Quick", since our target customers are researchers, they need a fast and easy way to track their studies and so here we are. During the development phase, I programmed all in Javascript for QRLims (a phone version) to decode QR code. 
				</p>
				<p>For QLims, our group developed
				send_email module, QR code Generator, sample and study management modules. I provided core Javascript programming works to connect UI (which was written with XDK) and Web Service. (In prototype we used PHP RESTFul)
				</p>
                    
				<div class="image" style="clear:both">
                      <div class="project_show_image" style="float:left">
               <a href="images/details_images/ASA_02.jpg" class="highslide" onclick="return hs.expand(this)"><img src="images/details_images/ASA_02.jpg" alt="Highslide JS" title="Click to enlarge" width="190" height="140"/></a>
                          <div>Management of 'Samples'</div>
                      </div>
                      
                      <div class="project_show_image" style="float:left">
               <a href="images/details_images/ASA_03.jpg" class="highslide" onclick="return hs.expand(this)"><img src="images/details_images/ASA_03.jpg" alt="Highslide JS" title="Click to enlarge" width="190" height="140"/></a>
                          <div>QR Code feature</div>
                      </div>
               </div>          	
                    
               <header>Result</header>
                      <div class="image" style="clear:both">
                      
					  <p>
						With the intense work of this 2-months' project, I came through with valuable experiences in Javascript Programming skills. Besides, I did some reasearch works in Mobile development methodology and tricks, which is 
						not bad. Our client, ASA was very content with our efforts and our prototype is taken as a furthur consideration.
					  </p>
                          
               		</div>   
                    
                
            </div>    
                
             </article>
 
            <article class="article_right">
            	<header>Type</header>
                <p>Enterprise project</p>
                <header>Time</header>
                <p>Spring 2013</p>
                <header>Methods & Skills</header> 
                <p>
                Javascript<br/>
                RESTFul API<br/>
                PhoneGap, JQuery Mobi<br/>
                <br/>
                </p>
                <header>Tools & Environment</header>
                <p>
               	MySQL<br/>
                XDK, Eclipse(Android SDK)<br/>
                Dreamweaver<br/>
                <br/>
                </p>
                <header>Results & Archivements</header> 
                <p>
                </p>         
            </article>  

 	</section>  

</div> 
          
   <!---aside, index for projects--->            
          
	<aside>
        <h3>PROJECTS</h3>
        <nav>
          <a href="javascript:include_ASA()">ASA QLIMS<br/>---Tablet prototype</a>
		  <a href="javascript:include_UVSP()" >UVSP<br/>---.NET Framework Dev</a>
          <a href="javascript:include_Pollaroid()">POLLAROID<br/>---iOS development</a>
          <a href="javascript:include_French_Airline()">French Airline<br/>---Algorithm in C</a>
          <a href="javascript:include_Stadium()">Service Management System<br/>---Web Based CMS</a>
          <a href="javascript:include_Expernova()">Expernova<br/>---Social Network Integration</a>
          <a href="javascript:include_Allons_y()">Allons-y Francais<br/>---French Teaching Video</a>
          <a href="javascript:include_Good_Deed_Movement()">Good Tracking Service<br/>Forum development</a>
          <a href="javascript:include_SLAB()">SLAB<br/>---Java Based Resource Planning System</a>
          <a href="javascript:include_Euronext()">Euronext<br/>---European Enterprises analysis</a>
          <a href="javascript:include_Mail_System()">Simple Chat<br/>---C based mailing system</a>
        </nav>      
	</aside>    
        
  </div><!---End of div container->
      
</html> 
              >
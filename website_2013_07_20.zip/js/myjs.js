// JavaScript Document

	jQuery.noConflict();
	  
    function include_home()
    {
		jQuery("#included").load("home.php");
    }
	
	function include_projects()
    {
		jQuery("#included").load("projects.php");
    }
	
	function include_about_me()
    {
		jQuery("#included").load("about_me.php");
    }
	
	function include_resume()
    {
		jQuery("#included").load("resume.php");
    }
	
	
	
	
	
	
	//Include project pages
	function include_ASA()
    {
		jQuery("#included").load("ASA.php");
    }
	
	
	function include_UVSP()
    {
		jQuery("#included").load("UVSP.php");
    }
	
	function include_Expernova()
    {
		jQuery("#included").load("Expernova.php");
    }
	
	function include_Pollaroid()
    {
		jQuery("#included").load("Pollaroid.php");
    }
	
	function include_French_Airline()
    {
		jQuery("#included").load("French_Airline.php");
    }
	
	function include_Stadium()
    {
		jQuery("#included").load("Stadium.php");
    }
	
	function include_Allons_y()
    {
		jQuery("#included").load("Allons-y.php");
    }
	
	function include_Good_Deed_Movement()
    {
		jQuery("#included").load("Good_Deed_Movement.php");
    }
	
	function include_SLAB()
    {
		jQuery("#included").load("SLAB.php");
    }
	
	function include_Euronext()
    {
		jQuery("#included").load("Euronext.php");
    }

	function include_Mail_System()
    {
		jQuery("#included").load("Mail_System.php");
    }
	


// JavaScript Document

jQuery.noConflict();
jQuery(document).ready(function(){
										
		jQuery("#facebook_icon").hover(
		
		function(){
				jQuery("#facebook_icon").fadeTo(300, 0.5);
		}, 
		
		function(){
				jQuery("#facebook_icon").fadeTo(300, 1.0);
		}
	);							
			
				
		jQuery("#linkedIn_icon").hover(
		
		function(){
				jQuery("#linkedIn_icon").fadeTo(300, 0.5);
		}, 
		function(){
				jQuery("#linkedIn_icon").fadeTo(300, 1.0);
		}
	);	
		

                jQuery("#viadeo_icon").hover(
		
		function(){
				jQuery("#viadeo_icon").fadeTo(300, 0.5);
		}, 
		function(){
				jQuery("#viadeo_icon").fadeTo(300, 1.0);
		}
	);	

		

});
      
// JavaScript Document

// JavaScript Document
// JavaScript Document

jQuery.noConflict();
//initialize header to faded..
jQuery(document).ready(function(){
										
		jQuery("article").each(function(){
												
			jQuery("article").fadeTo(300, 0.55);
			
			jQuery(this).hover(
				function(){
					jQuery(this).fadeTo(300, 1.0);
				}, 
		
				function(){
					jQuery(this).fadeTo(300, 0.55);
				});	
		});
});
		
		
		
function sharpen_ASA()
{
	jQuery("#article_ASA").fadeTo(300, 1.0);
}		

function restore_ASA()
{
	jQuery("#article_ASA").fadeTo(300, 0.55);
}				
		
function sharpen_UVSP()
{
	jQuery("#article_UVSP").fadeTo(300, 1.0);
}		

function restore_UVSP()
{
	jQuery("#article_UVSP").fadeTo(300, 0.55);
}
		
function sharpen_pollaroid()
{
	jQuery("#article_pollaroid").fadeTo(300, 1.0);
	
}

function restore_pollaroid()
{
	jQuery("#article_pollaroid").fadeTo(300, 0.55);
}
		


//////	
function sharpen_french()
{
	jQuery("#article_french").fadeTo(300, 1.0);
	
}

function restore_french()
{
	jQuery("#article_french").fadeTo(300, 0.55);
}


//////	
function sharpen_stadium()
{
	jQuery("#article_stadium").fadeTo(300, 1.0);
	
}

function restore_stadium()
{
	jQuery("#article_stadium").fadeTo(300, 0.55);
}


//////	
function sharpen_expernova()
{
	jQuery("#article_expernova").fadeTo(300, 1.0);
	
}

function restore_expernova()
{
	jQuery("#article_expernova").fadeTo(300, 0.55);
}


///////	
function sharpen_allons_y()
{
	jQuery("#article_allons-y").fadeTo(300, 1.0);
	
}

function restore_allons_y()
{
	jQuery("#article_allons-y").fadeTo(300, 0.55);
}


///////	
function sharpen_gdm()
{
	jQuery("#article_gdm").fadeTo(300, 1.0);
	
}

function restore_gdm()
{
	jQuery("#article_gdm").fadeTo(300, 0.55);
}



//////		
function sharpen_slab()
{
	jQuery("#article_slab").fadeTo(300, 1.0);
	
}

function restore_slab()
{
	jQuery("#article_slab").fadeTo(300, 0.55);
}



////////	
function sharpen_euronext()
{
	jQuery("#article_euronext").fadeTo(300, 1.0);
	
}

function restore_euronext()
{
	jQuery("#article_euronext").fadeTo(300, 0.55);
}



////////	
function sharpen_mail()
{
	jQuery("#article_mail").fadeTo(300, 1.0);
	
}

function restore_mail()
{
	jQuery("#article_mail").fadeTo(300, 0.55);
}



      							
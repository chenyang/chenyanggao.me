<!DOCTYPE html>
<html>
<link rel="stylesheet" href="css/projects_detail.css">
	

        
<!---div projects_left, show of projects--->
<div id="projects_detail">
     <section>
           	<article class="article_left">
            <div class="project_description">
            <h2>
            	UVSP: .NET MVC based course management system
            </h2>
            <img src="images/projects_images/UVSP.png" width="200" height="120" align="right" style="margin-top:10px"/>
            <p>During this short-time project our group realised a functional university source planning system based on .NET MVC4 technology. I provided all web api programming and testing works and 2 parts of CMS. (reservation and courses management).            </p>
            </div>
            
            
            
            <div class="project_precision">
            	<header>Overview</header>
              <p>
              Based on the previous result of java version CMS, we have re-built the project with .Net version. The final result include reservation, course, teacher, class and time scheduling management. During the project, I wrote all Web APIs using .Net MVC framework and realized 2 main parts of system: course and reservation management.
              </p>
              <br/>
              
                
              </p>
                <header>Function requirements and technology choosing</header>
                <div class="image" style="clear:both">
                      <div class="project_show_image" style="float:left">
                <a href="images/details_images/UVSP_01.png" class="highslide" onclick="return hs.expand(this)"><img src="images/details_images/UVSP_01.png" alt="Highslide JS" title="Click to enlarge" width="190" height="140"/></a>
                          <div>System Architecture</div>
                      </div>
                      
                      <div class="project_show_image" style="float:left">
               <a href="images/details_images/UVSP_02.png" class="highslide" onclick="return hs.expand(this)"><img src="images/details_images/UVSP_02.png" alt="Highslide JS" title="Click to enlarge" width="190" height="140"/></a>
                          <div>Web API Architecture</div>
                      </div>
               </div>          
				<p>As our project is based on the product (java version) that we have realized, we have decided to rebulid the system without changing our database. And for a limited group member of 4, we have finally chosen .NET MVC 4 as our fast-pace development framework. .NET MVC Framework also has a confortable ORM framework: EntityFramework and an easy REST Web Service which allows us to fastly extend our business.
				During the starting phase of our project, I participated and involved in technology choosing decision.</p>
				
      			<header>.Net MVC4 and Web API development</header> 
                    <p>
						The implementation contains 3 parts: UI, Web application and Web Service (Web API). I was responsible for .NET Web API development and testing works. Also I realized 2 parts (CRUD) of system under .Net MVC Framework. 
						For API and Web application development, I used .Net Entity Framework as method that manipulates SQL Server database.
                    </p>
                    
                    
               <header>Result</header>
                      <div class="image" style="clear:both">
                      
					  <p>
					  After a 2 months' intense development, our team of 4 realized all functionalities that we expected to develop and realized main Web APIs for future extension of our project. I established a general sense of .NET Framework and practiced a lot of using MVC design pattern . Final Doucmentation and links is <a href="https://github.com/chenyang/UVSP">here</a>.
					  
					  </p>
                          
               		</div>   
                    
                
            </div>    
                
             </article>
 
            <article class="article_right">
            	<header>Type</header>
                <p>Course project</p>
                <header>Time</header>
                <p>Winter 2012</p>
                <header>Methods & Skills</header> 
                <p>
                C#, .NET MVC 4<br/>
                Web API Development<br/>
                .NET Entity Framework<br/>
				UI Design, Bootstrap<br/>
                <br/>
                </p>
                <header>Tools & Environment</header>
                <p>
               	.NET 4.5 environment<br/>
                Visual Studio 2012 Express<br/>
                SQL Server 2012 Express<br/>
                </p>
                <header>Results & Archivements</header> 
                <p>
                Source Code<br/>
                Documentation
                </p>         
            </article>  

 	</section>  

</div> 
          
   <!---aside, index for projects--->            
          
	<aside>
        <h3>PROJECTS</h3>
        <nav>
         <a href="javascript:include_ASA()">ASA QLIMS<br/>---Tablet prototype</a>
		  <a href="javascript:include_UVSP()" >UVSP<br/>---.NET Framework Dev</a>
          <a href="javascript:include_Pollaroid()">POLLAROID<br/>---iOS development</a>
          <a href="javascript:include_French_Airline()">French Airline<br/>---Algorithm in C</a>
          <a href="javascript:include_Stadium()">Service Management System<br/>---Web Based CMS</a>
          <a href="javascript:include_Expernova()">Expernova<br/>---Social Network Integration</a>
          <a href="javascript:include_Allons_y()">Allons-y Francais<br/>---French Teaching Video</a>
          <a href="javascript:include_Good_Deed_Movement()">Good Tracking Service<br/>Forum development</a>
          <a href="javascript:include_SLAB()">SLAB<br/>---Java Based Resource Planning System</a>
          <a href="javascript:include_Euronext()">Euronext<br/>---European Enterprises analysis</a>
          <a href="javascript:include_Mail_System()">Simple Chat<br/>---C based mailing system</a>
        </nav>      
	</aside>    
        
  </div><!---End of div container->
      
</html> 
              >
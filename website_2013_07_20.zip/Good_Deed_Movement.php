<!DOCTYPE html>
<html>
<link rel="stylesheet" href="css/projects_detail.css">
	

        
<!---div projects_left, show of projects--->
<div id="projects_detail">
     <section>
           	<article class="article_left">
            <div class="project_description">
            <h2>
            	Good Tracking Service: Forum Construction for NPO in Chicago
            </h2>
            <img src="images/projects_images/Good_Deed_Movement.png" width="200" height="120" align="right" style="margin-top:10px;"/>
            <p>
            During school year of 2011, worked as a part time web Developer, I helped the founder reconstructed 3 portions of the website for NPO in Chicago "Good Deed Movement": Good Tracking service (Forum with Google API embedded), Suggestion portion and Printable Material (Automatic ticks generation)page.
            </p>
            </div>
            
            
            
            <div class="project_precision">
            	<header>Overview</header>
              <p>
              <a href="http://www.thegooddeedmovement.com">The Good Deed Movement</a> is a 501(c)3 organization located in Chigaco, IL. The organization creates and supports threads of good deeds, by offering good-doers a forum to journal their experiences and pay their deeds forward. Good-doers can find the company on business cards, wristbands, key chains, and anyway they are reminded.
          <img src="images/details_images/GDM_01.jpg" width="200" height="120" align="right" style="margin-top:30px;"/> 
              </p>
              
              <p>
               During my free lance work, I re-constructed "Suggestion" and "Printable Material" portion of the website and I created the "Good Tracking Service" forum for "Good Tracking" part. Other pages of website were initially created by the company but they used Mac Web tool. (The structure of website was mixed)
              </p>
              
              <header>Requirements & Early Stage</header>
              <p>
             	The free lance work assigned me mainly 2 portion of tasks: One major one was changing the website structure to PHP as the website was initially constructed by frame iWeb. Antoher one was the development of "Good Tracking Forum" and other re-construction of other parts of the website. 
              </p> 
                            
              <p>
              	During my early stage of the work, I met some difficulties in analysing the code written by iMac. The structure of web was quite different from a normal method such as using PHP+HTML/CSS. I communicated a lot with founder and technical personnel to discuss strategic and technical issues. With their help, I successfully re-formed the structure of website and decided to use php+mysql based on GoDaddy Server.
              </p>
              
               <header>Forum Development</header>
                <p>
                	In the middle of November, I started the design and implementation of "Good Tracking Service" Forum. The idea of this forum was initially simple: There was no registration of user but just their Good Deed Number, name and location. The user login by typing Good Deed Number and they can see related story of his or her good. 
                </p> 
                <h3>Database Design</h3>
                <p>
                	Database design was quite simple and was initially no more than 2 entities: "User" and "Post". In the stage of maintenance and imporvemnt, I added 2 enties: "File" to store related information that user uploaded to server and "Suggestion" to collect users' advices.
                </p>
                <h3>Function development</h3>
                <p>In this stage, besides the tasks assigned to me(Chatting forum), I added additional functionalities to make the forum more attractive and user friendly. 
                </p>
                <p>
                In general, I created 4 additional functions: 1. Upload File 2. Upload Pic 3. Share Youtube video and 4. Share a link.
                The forum can translate the key words such as "[link]the content[/link]" to generate a link. For the feature of "Share a link", I developed a prototype method that can intelligently analysis webpage and generate the "quick-shot" like "Facebook Share" or "Google Share". Besides, I added a "business logic" that users can upload their good pics before registration.
                </p>
                <div class="image" style="clear:both">
                      
                          <div class="project_show_image" style="float:left">
                <a href="images/details_images/GDM_09.jpg" class="highslide" onclick="return hs.expand(this)"><img src="images/details_images/GDM_09.jpg" alt="Highslide JS" title="Click to enlarge" width="190" height="140"/></a>
                              <div>Main Functions</div>
                          </div>
                          
                          <div class="project_show_image" style="float:left">
               <a href="images/details_images/GDM_10.jpg" class="highslide" onclick="return hs.expand(this)"><img src="images/details_images/GDM_10.jpg" alt="Highslide JS" title="Click to enlarge" width="190" height="140"/></a>
                              <div>Screenshot of "Tracking" Forum</div>
                          </div>
               	</div>   
                <div class="image" style="clear:both">
                      
                          <div class="project_show_image" style="float:left">
                <a href="images/details_images/GDM_03.jpg" class="highslide" onclick="return hs.expand(this)"><img src="images/details_images/GDM_03.jpg" alt="Highslide JS" title="Click to enlarge" width="190" height="140"/></a>
                              <div>"Share a link" Feature</div>
                          </div>
                          
                          <div class="project_show_image" style="float:left">
               <a href="images/details_images/GDM_05.jpg" class="highslide" onclick="return hs.expand(this)"><img src="images/details_images/GDM_05.jpg" alt="Highslide JS" title="Click to enlarge" width="190" height="140"/></a>
                              <div>Screenshot of "Tracking" Forum</div>
                          </div>
               	</div>   
                
                <h3>About Good Tracking</h3>
                <p>
                	Initially the idea of "Good Tracking" according to the company was that when a user types his or her code in the system, he or she can see the related comments and know the story of his or her good. Personnaly (After discussion with Founder) I added the feature of Google Map Integration (Location Analyse based on Javascript). Each time the user opens his thread, he can click "Click to see where good deed has been in the world!" on the top of the body and get a more intuitive sense. 
                </p>
                
                <div class="image" style="clear:both">
                      
                          <div class="project_show_image">
              <a href="images/details_images/GDM_04.jpg" class="highslide" onclick="return hs.expand(this)"><img src="images/details_images/GDM_04.jpg" alt="Highslide JS" title="Click to enlarge" width="190" height="140"/></a>
                              <div>"Good Tracking" Feature based on Javascript & Google API</div>
                          </div>
               	</div> 
                
                
               <header>Suggestion Page & Printable Material</header>
               
                <p>
                At the beginning of Janurary 2012, I conducted the other parts of website construction, included "Suggestion"and "Printable Material" and small fixes over other pages. Visit <a href="http://www.thegooddeedmovement.com">Good Deed Movement Website</a> to see my final product. "Printable Material" is a webpage that can automatically generate tickets as user visit it and would like to print them out.
                
                
                </p>   
                
               <header>Extension & Result</header>
               	<p>
               		During my free lance job, the founder of the company transfered the website to GoDaddy server and I configured the mysql database and website files.I communicated with founder and technical personnel in the company remotely from Fracne. <a href="images/downloads/Good_Deed_Movement.pdf">Here is one letter from the founder of "Good Deed Movement"</a>. And for the moment, I still work volunteerly for the web issues if the company demands me to do so. 
				</p>

                      
    		</div><!--End of div project_precision--->    
            </article>
 
            <article class="article_right">
            	<header>Type</header>
                <p>job project</p>
                <header>Time</header>
                <p>Winter 2011 - Spring 2012</p>
                <header>Methods & Skills</header> 
                <p>
                PHP development<br/>
                Database Design<br/>
               	HTML/CSS/Javascript<br/>
                Google API integration<br/>
                Server Configuration<br/>
                </p>
                <header>Tools & Environment</header>
                <p>
               	Server GoDaddy<br/>
                Linux Ubuntu<br/>
                Dreamweaver<br/>
                Photoshop<br/>
                </p>
                <header>Results & Archivements</header> 
                <p>
                Website<br/>
                </p>         
            </article>  

 	</section>  

</div> 
          
   <!---aside, index for projects--->            
          
	<aside>
        <h3>PROJECTS</h3>
        <nav>
         <a href="javascript:include_ASA()">ASA QLIMS<br/>---Tablet prototype</a>
		  <a href="javascript:include_UVSP()" >UVSP<br/>---.NET Framework Dev</a>
          <a href="javascript:include_Pollaroid()">POLLAROID<br/>---iOS development</a>
          <a href="javascript:include_French_Airline()">French Airline<br/>---Algorithm in C</a>
          <a href="javascript:include_Stadium()">Service Management System<br/>---Web Based CMS</a>
          <a href="javascript:include_Expernova()">Expernova<br/>---Social Network Integration</a>
          <a href="javascript:include_Allons_y()">Allons-y Francais<br/>---French Teaching Video</a>
          <a href="javascript:include_Good_Deed_Movement()">Good Tracking Service<br/>Forum development</a>
          <a href="javascript:include_SLAB()">SLAB<br/>---Java Based Resource Planning System</a>
          <a href="javascript:include_Euronext()">Euronext<br/>---European Enterprises analysis</a>
          <a href="javascript:include_Mail_System()">Simple Chat<br/>---C based mailing system</a>
        </nav>      
	</aside>    
        
  </div><!---End of div container->
      
</html> 
              >